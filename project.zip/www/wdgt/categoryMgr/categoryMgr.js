var categoryMgr = {
	fPathRoot : "",
	fCatBtns : [],
	fStrings : ["Filtrer par catégories","Filtrer par type",
	/*02*/      "Voir la recherche par catégories","Masquer la recherche par catégories",
	/*04*/      "Catégories", " Cliquez pour sélectionnez/désélectionnez"],


/* === Public functions ===================================================== */
	init : function (pPathRoot){
		scCoLib.util.log("categoryMgr.init");
		if (typeof pPathRoot != "undefined") this.fPathRoot = pPathRoot;
		scOnLoads.push(this);
	},

	onLoad : function(){
		scCoLib.util.log("categoryMgr.onLoad");
		try{
			var vMnu = this.xBuildFilters(lexiconMgr.fLexiconJson, searchMgr.fSearchCmds);


			for (var i = 0; i < this.fCatBtns.length; i++) {
				var vSchFilter = this.fCatBtns[i], vSchFilterVal = vSchFilter.getAttribute("data-val");
				vFilters += vSchFilterVal + " ";
				if(tplMgr.fStore.get(vSchFilterVal)=="true") {
					vSchFilter.checked=true;
					vSchFilter.setAttribute("data-ison",true);
					searchMgr.fFilter = true;
				}
			}
			if(searchMgr.fFilter == true) vFilterContainer.click();
			tplMgr.fStore.set("filters",vFilters);
		} catch(e){
			scCoLib.util.log("ERROR - categoryMgr.onLoad: "+e);
		}
	},


/* === Callback functions =================================================== */
	/** categoryMgr.sShowFilter : Filter callback : called on search a successful. */
	sShowFilterRadio: function(){

		vCrits = scPaLib.findNodes("des:input.schCrit");

		for (var i = 1; i < this.length; i++) {
			if (this.options[i].selected==true) {
				for (var j = 0; j < vCrits.length; j++){
					vCrits[j].setAttribute("data-ison","false");
					if (vCrits[j].value==this.options[i].value) {
						
						if(vCrits[j].attributes["data-ison"].value=="false") {vCrits[j].setAttribute("data-ison","true");} else  {vCrits[j].setAttribute("data-ison","false")};
					};

				};

			};
		
		};
		searchMgr.findFilters();
		searchMgr.find();
	},

	sShowFilterCheckbox: function(){

		vCrits = scPaLib.findNodes("des:input.schCrit");

		for (var i = 1; i < this.length; i++) {
				for (var j = 0; j < vCrits.length; j++){
					if(!vCrits[j].attributes["data-ison"]) vCrits[j].setAttribute("data-ison","false");
					if (vCrits[j].value==this.options[i].value) {
						
						if((this.options[i].selected==true)&&(vCrits[j].attributes["data-ison"].value=="false")) vCrits[j].setAttribute("data-ison","true");
						if((this.options[i].selected==false)&&(vCrits[j].attributes["data-ison"].value=="true")) vCrits[j].setAttribute("data-ison","false");
					};

				};

		
		};
		searchMgr.findFilters();
		searchMgr.find();
	},

	
	/** categoryMgr.sToggleMnu. */
	sToggleMnu: function(){
		if(!this) return;
		var vState = this.mnu.toggleState;
		vState = vState?false:true;
		// this.title = vState?categoryMgr.fStrings[3]:categoryMgr.fStrings[2];
		categoryMgr.xSwitchClass(this.mnu, vState?"display_off":"display_on", vState?"display_on":"display_off", true);
		this.mnu.toggleState = vState;
		if(!vState) categoryMgr.xReset();
		return false;
	},

/* === Private functions ==================================================== */
	xReset : function() {
		for (var i = 0; i < this.fCatBtns.length; i++) {
			var vSchFilter = this.fCatBtns[i];
			vSchFilter.checked=false;
			vSchFilter.setAttribute("data-ison",false);
		}
		searchMgr.fFilter = false;
		searchMgr.findFilters();
		searchMgr.find();
	},

	xBuildFilters : function(pLexicon,pRoot) {
		//scCoLib.util.log("categoryMgr.buildFilters");
		if(!pLexicon || pLexicon.tags.length == 1 || !pRoot) return;
		pLexicon.tags.sort(function (a, b) {
			if (!a) return 1;
			if (!b) return -1;
			if ((a.family+a.value).toLowerCase() > (b.family+b.value).toLowerCase()) return 1;
			if ((a.family+a.value).toLowerCase() < (b.family+b.value).toLowerCase()) return -1;
			return 0;
		});
		
		var vIdxGrps = {};
		var vCountType=0;
		var vCountFilter=0;
		var vFamily="";
		
		for (var i = 0; i < pLexicon.tags.length-1; i++) {
			(pLexicon.tags[i].classe) ? vCountType++ : vCountFilter++;
		};
		
		if (vCountType > 1 || vCountFilter > 0) {
		var vCategCmds = this.fCategCmds = scDynUiMgr.addElement("div",searchMgr.fSchBox,"grey-bg text-center-xs container-fluid");
		var vForm2 = this.fForm2 = scDynUiMgr.addElement("form",vCategCmds,"navbar-form navbar-right categ-bar");
			vForm2.setAttribute("role","search");
		};

		var vFieldSet= this.fFieldSet = scDynUiMgr.addElement("fieldset",vForm2,"hidden");
		
		
		if (vCountType > 1) {
		
			var vSelect1= this.fSelect1 = scDynUiMgr.addElement("select",vForm2,"selectpicker");
			vSelect1.setAttribute("data-width","auto");
			vSelect1.setAttribute("name","Choisir un type de fiche");
			vSelect1.setAttribute("title","Choisir un type de fiche");
			vSelect1.id="typeselect";
			var vOption1=this.fOption1 = scDynUiMgr.addElement("option",vSelect1,"");
			vOption1.setAttribute("selected","");

			vOption1.setAttribute("data-content","<span class='type0-ico'>Tous les types</span>");

			
			};

		if (vCountFilter > 0) {
			
			var vSelect2= this.fSelect2 = scDynUiMgr.addElement("select",vForm2,"selectpicker");
			vSelect2.setAttribute("data-width","auto");
			vSelect2.setAttribute("multiple","");
			vSelect2.setAttribute("data-live-search","true");
			vSelect2.setAttribute("data-live-search-placeholder","Rechercher une catégorie...");
			vSelect2.setAttribute("data-actions-box","false");
			vSelect2.setAttribute("name","Choisir des catégories");
			vSelect2.setAttribute("title","Choisir des catégories");
			vSelect2.id="tagselect";
			
			};

		for (var i = 0; i < pLexicon.tags.length-1; i++) {
			var vChi = pLexicon.tags[i];
			
			if(vChi.classe) {
				var vOption=scDynUiMgr.addElement("option",vSelect1,"");
				vOption.setAttribute("data-content","<span class='"+vChi.classe+"-ico'>"+vChi.value+"</span>");
				vOption.type = vChi.key;
				
			}

			else {

				if ((vChi.family !="")&&(vFamily==vChi.family)) {
					vOption=scDynUiMgr.addElement("option",vOptGrp,"");
				
				};

				if ((vChi.family != "") && (vFamily != vChi.family)) {
					vOptGrp = scDynUiMgr.addElement("optgroup",vSelect2,"");
					vOptGrp.setAttribute("label",vChi.family);
					vOption=scDynUiMgr.addElement("option",vOptGrp,"");
			
					vFamily=vChi.family;
				};

				

				if (vChi.family =="") {
					vOption=scDynUiMgr.addElement("option",vSelect2,"");
					
				};


			};

			vOption.innerHTML = vChi.value;
			vOption.value = vChi.key;
			var vInput=scDynUiMgr.addElement("input",vFieldSet,"schCrit")
			vInput.value = vChi.key;

			vInput.setAttribute("data-val",vChi.key)
			vInput.setAttribute("data-index",vChi.index);
			
			
			vSelect1.onchange = this.sShowFilterRadio;
			vSelect2.onchange = this.sShowFilterCheckbox;
			};
		
	
		


},

	


	
/* === Utilities =========================================================== */
	xInputReset: function(pTag) {
		for (var i=0; i < pTag.length-1; i++) {
		$(pLexicon.tags[i].value +' :input').val('');
		};
		searchMgr.fFilter = false;
		searchMgr.findFilters();
		searchMgr.find();
		},

	
	
	/** categoryMgr.xAddBtn : Add a HTML button to a parent node. */
	xAddBtn : function(pParent, pClassName, pCapt, pTitle, pNxtSib) {
		var vBtn = pParent.ownerDocument.createElement("button");
		vBtn.className = pClassName;
		vBtn.fName = pClassName;
		if (pTitle) vBtn.setAttribute("title", pTitle);
		if (pCapt) vBtn.innerHTML = '<span class="capt">' + pCapt + '</span>';
		if (pNxtSib) pParent.insertBefore(vBtn,pNxtSib);
		else pParent.appendChild(vBtn);
		return vBtn;
	},
	
	
	/** categoryMgr.xSwitchClass - replace a class name. */
	xSwitchClass : function(pNode, pClassOld, pClassNew, pAddIfAbsent, pMatchExact) {
		var vAddIfAbsent = typeof pAddIfAbsent == "undefined" ? false : pAddIfAbsent;
		var vMatchExact = typeof pMatchExact == "undefined" ? true : pMatchExact;
		var vClassName = pNode.className;
		var vReg = new RegExp("\\b"+pClassNew+"\\b");
		if (vMatchExact && vClassName.match(vReg)) return;
		var vClassFound = false;
		if (pClassOld && pClassOld != "") {
			if (vClassName.indexOf(pClassOld)==-1){
				if (!vAddIfAbsent) return;
				else if (pClassNew && pClassNew != '') pNode.className = vClassName + " " + pClassNew;
			} else {
				var vCurrentClasses = vClassName.split(' ');
				var vNewClasses = new Array();
				for (var i = 0, n = vCurrentClasses.length; i < n; i++) {
					var vCurrentClass = vCurrentClasses[i];
					if (vMatchExact && vCurrentClass != pClassOld || !vMatchExact && vCurrentClass.indexOf(pClassOld) != 0) {
						vNewClasses.push(vCurrentClasses[i]);
					} else {
						if (pClassNew && pClassNew != '') vNewClasses.push(pClassNew);
						vClassFound = true;
					}
				}
				pNode.className = vNewClasses.join(' ');
			}
		}
		return vClassFound;
	},
	loadSortKey : "ZZCategoryMgr",
};



