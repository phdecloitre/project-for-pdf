/* template manager */
var tplMgr = {
	fCbkClosedPath : "des:.cbkClosed",
	fCbkOpenPath : "des:.cbkOpen",
	fWaiMnuPath : "ide:accessibility",
	fWaiBtnPath : "des:.waiBtn",
	fRootPath : "des:.tplFra",
	fHomeBtnPath : "des:.homeBtn",
	fListeners : {showSearchTerms:[],showSearchFull:[],resetSearch:[],noSearchResult:[]},
	
	fStrings : ["Cacher le contenu de \'%s\'","Afficher le contenu de \'%s\'",
	/*02*/      "",""],
	
	init : function(){
		scCoLib.util.log("tplMgr.init");
		// Accessibility menu focus.
		var vWaiMnu = scPaLib.findNode(this.fWaiMnuPath);
		if (vWaiMnu){
			vWaiMnu.fClass = vWaiMnu.className;
			var vWaiBtns = scPaLib.findNodes(this.fWaiBtnPath,vWaiMnu);
			for (var i in vWaiBtns) {
				vWaiBtns[i].onfocus = function(){vWaiMnu.className = vWaiMnu.fClass + " waiFocus"}
				vWaiBtns[i].onblur = function(){vWaiMnu.className = vWaiMnu.fClass}
			}
		}

		// Set callback functions.
		if ("scDynUiMgr" in window ) {
			scDynUiMgr.subWindow.addOpenListener(this.sSubWinOpen);
			scDynUiMgr.subWindow.addCloseListener(this.sSubWinClose);
			scDynUiMgr.collBlk.addOpenListener(this.sCollBlkOpen);
			scDynUiMgr.collBlk.addCloseListener(this.sCollBlkClose);
		}
		if ("scTooltipMgr" in window ) {
			scTooltipMgr.addShowListener(this.sTtShow);
			scTooltipMgr.addHideListener(this.sTtHide);
		}

		// Close collapsable blocks that are closed by default.
		var vCbks = scPaLib.findNodes(this.fCbkClosedPath);
		for (var i in vCbks) {
			var vTgl = scPaLib.findNode("des:a", vCbks[i]);
			if (vTgl) vTgl.onclick();
		}
		vCbks = scPaLib.findNodes(this.fCbkOpenPath);
		for (var i in vCbks) {
			var vTgl = scPaLib.findNode("des:a", vCbks[i]);
			if (vTgl) vTgl.title = tplMgr.fStrings[0].replace("%s", (vTgl.innerText ? vTgl.innerText: vTgl.textContent));
		}

		this.fRoot = scPaLib.findNode(this.fRootPath);
		var vHomeBtn = scPaLib.findNode(this.fHomeBtnPath);
		if(vHomeBtn) vHomeBtn.onclick = function() {
			tplMgr.fStore.set("input","");
			var vFiltersArr = tplMgr.fStore.get("filters").split(" ");
			for (var i = 0; i < vFiltersArr.length; i++) tplMgr.fStore.set(vFiltersArr[i],"");
		};
		this.fStore = new this.LocalStore();
		this.fCurrentUrl = document.location.href;
		var vPageCurrent = "co/"+this.fCurrentUrl.substring(this.fCurrentUrl.lastIndexOf("/")+1);
		this.fPageCurrent = vPageCurrent.lastIndexOf('#') == -1?vPageCurrent:vPageCurrent.substring(0,vPageCurrent.lastIndexOf('#'));
		
	},
	registerListener : function(pListener, pFunc){
		//scCoLib.util.log("frameMgr.registerListener");
		if (this.fListeners[pListener]) this.fListeners[pListener].push(pFunc);
		else scCoLib.util.log("ERROR - tplMgr.registerListener - non-existent listener : " + pListener);
	},
	fireEvent : function(pListener, pParam){
		//scCoLib.util.log("frameMgr.fireEvent : "+pListener);
		if (this.fListeners[pListener]) for (var i=0; i< this.fListeners[pListener].length; i++) this.fListeners[pListener][i](pParam);
		else scCoLib.util.log("ERROR - tplMgr.fireEvent - non-existent listener : " + pListener);
	},
	/** Callback function. */
	sSubWinOpen: function(pId) {
		var vSub = scDynUiMgr.subWindow.fSubWins[pId];
		if (!vSub) return;
		vSub.style.position = "";
		vSub.fOver.style.position = "";
		var vClsBtn = scPaLib.findNode("anc:div/chi:a", vSub.fTi); 
		if (vClsBtn) vClsBtn.focus();
	},
	/** Callback function. */
	sSubWinClose: function(pId) {
		var vSub = scDynUiMgr.subWindow.fSubWins[pId];
		if (!vSub) return;
		if (vSub.fAnc) vSub.fAnc.focus();
	},
	/** Tooltip lib show callback */
	sTtShow: function(pNode) {
		var vClsBtn = scPaLib.findNode("des:a.tt_x", scTooltipMgr.fCurrTt);
		if (vClsBtn) window.setTimeout(function(){vClsBtn.focus();}, pNode.fOpt.DELAY + 10);
	},
	/** Tooltip lib hide callback : this = scTooltipMgr */
	sTtHide: function(pNode) {
		if (pNode) pNode.focus();
	},
	/** Callback function. */
	sCollBlkOpen: function(pCo, pTitle) {
		if (pTitle) pTitle.title = tplMgr.fStrings[0].replace("%s", (pTitle.innerText ? pTitle.innerText: pTitle.textContent));
	},
	/** Callback function. */
	sCollBlkClose: function(pCo, pTitle) {
		if (pTitle) pTitle.title = tplMgr.fStrings[1].replace("%s", (pTitle.innerText ? pTitle.innerText: pTitle.textContent));
	},

/* === Utilities ============================================================ */
	/** tplMgr.xAddBtn : Add a HTML button to a parent node. */
	xAddBtn : function(pParent, pClassName, pCapt, pTitle, pNxtSib) {
		var vBtn = pParent.ownerDocument.createElement("a");
		vBtn.className = pClassName;
		vBtn.fName = pClassName;
		vBtn.href = "#";
		vBtn.target = "_self";
		if (pTitle) vBtn.setAttribute("title", pTitle);
		if (pCapt) vBtn.innerHTML = '<span class="capt">' + pCapt + '</span>';
		if (pNxtSib) pParent.insertBefore(vBtn,pNxtSib);
		else pParent.appendChild(vBtn);
		return vBtn;
	},

	/** tplMgr.xSwitchClass - replace a class name. */
	xSwitchClass : function(pNode, pClassOld, pClassNew, pAddIfAbsent, pMatchExact) {
		var vAddIfAbsent = typeof pAddIfAbsent == "undefined" ? false : pAddIfAbsent;
		var vMatchExact = typeof pMatchExact == "undefined" ? true : pMatchExact;
		var vClassName = pNode.className;
		var vReg = new RegExp("\\b"+pClassNew+"\\b");
		if (vMatchExact && vClassName.match(vReg)) return;
		var vClassFound = false;
		if (pClassOld && pClassOld != "") {
			if (vClassName.indexOf(pClassOld)==-1){
				if (!vAddIfAbsent) return;
				else if (pClassNew && pClassNew != '') pNode.className = vClassName + " " + pClassNew;
			} else {
				var vCurrentClasses = vClassName.split(' ');
				var vNewClasses = new Array();
				for (var i = 0, n = vCurrentClasses.length; i < n; i++) {
					var vCurrentClass = vCurrentClasses[i];
					if (vMatchExact && vCurrentClass != pClassOld || !vMatchExact && vCurrentClass.indexOf(pClassOld) != 0) {
						vNewClasses.push(vCurrentClasses[i]);
					} else {
						if (pClassNew && pClassNew != '') vNewClasses.push(pClassNew);
						vClassFound = true;
					}
				}
				pNode.className = vNewClasses.join(' ');
			}
		}
		return vClassFound;
	},

	/** Local Storage API (localStorage/userData/cookie) */
	LocalStore : function (pId){
		if (pId && !/^[a-z][a-z0-9]+$/.exec(pId)) throw new Error("Invalid store name");
		this.fId = pId || "";
		this.fRootKey = document.location.pathname.substring(0,document.location.pathname.lastIndexOf("/")) +"/";
		if ("localStorage" in window) {
			this.get = function(pKey) {var vRet = localStorage.getItem(this.fRootKey+this.xKey(pKey));return (typeof vRet == "string" ? unescape(vRet) : null)};
			this.set = function(pKey, pVal) {localStorage.setItem(this.fRootKey+this.xKey(pKey), escape(pVal))};
		} else if (window.ActiveXObject){
			this.get = function(pKey) {this.xLoad();return this.fIE.getAttribute(this.xEsc(pKey))};
			this.set = function(pKey, pVal) {this.fIE.setAttribute(this.xEsc(pKey), pVal);this.xSave()};
			this.xLoad = function() {this.fIE.load(this.fRootKey+this.fId)};
			this.xSave = function() {this.fIE.save(this.fRootKey+this.fId)};
			this.fIE=document.createElement('div');
			this.fIE.style.display='none';
			this.fIE.addBehavior('#default#userData');
			document.body.appendChild(this.fIE);
		} else {
			this.get = function(pKey){var vReg=new RegExp(this.xKey(pKey)+"=([^;]*)");var vArr=vReg.exec(document.cookie);if(vArr && vArr.length==2) return(unescape(vArr[1]));else return null};
			this.set = function(pKey,pVal){document.cookie = this.xKey(pKey)+"="+escape(pVal)};
		}
		this.xKey = function(pKey){return this.fId + this.xEsc(pKey)};
		this.xEsc = function(pStr){return "LS" + pStr.replace(/ /g, "_")};
	}
}