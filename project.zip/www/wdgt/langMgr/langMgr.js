/* === Lang manager =============================================== */
var langMgr = {
	fTplTopPath : "tplTop",
	fIsLocal : window.location.protocol == "file:",

/* === Public API =========================================================== */
	/** init function - must be called at the end of page body */
	init : function(){
		try {
			var vCurrentUrl = window.location.href,
				vLangs = ["fr","en"],
				vRootLang = vCurrentUrl.substring(0,vCurrentUrl.lastIndexOf("/co")),
				vCurrentLang = vRootLang.substring(vRootLang.lastIndexOf("/")+1),
				vPageUrl = vCurrentUrl.substring(vCurrentUrl.lastIndexOf("/co"));

			if(!this.xInArray(vLangs,vCurrentLang)) return;

			this.fLangBk = scDynUiMgr.addElement("div",sc$(this.fTplTopPath),"lang_bk");

			for(var i = 0; i < vLangs.length; i++) {
				vRootUrl = vCurrentUrl.substring(0,vCurrentUrl.lastIndexOf("/"+vLangs[i]));
				if(vRootUrl) {
					for (var j = 0; j < vLangs.length; j++) {
						var vLangUrl = "../../"+vLangs[j]+vPageUrl;
						if(j != i && this.xIsPageExist(vLangUrl)) this.xAddLangBtn(vLangs[j],vLangUrl);
					}
				}
			}
		} catch(e) {
			alert("L'initialisation de la page a échouée : "+e);
		}
	},
	xIsPageExist : function(pFile) {
		var vReq = null;
		if(window.XMLHttpRequest && (!this.fIsLocal || !window.ActiveXObject)) vReq = new XMLHttpRequest();
  		else if(window.ActiveXObject) vReq = new ActiveXObject("Microsoft.XMLHTTP");
		vReq.open("GET", pFile, false);	
		// null est ajouté dans le send pour contourner une erreur dans FF3 qui demande un argument dans le send alors que celui-ci est optionnel
		vReq.send(null);
		if (vReq.readyState==4)
			return vReq.status!=404;
	},
	xAddLangBtn : function(pLang,pUrl) {
		var vLangBtn = this.xAddBtn(this.fLangBk,"lang_"+pLang,pLang);
		vLangBtn.href = pUrl;
	},
	/** langMgr.xAddBtn : Add a HTML button to a parent node. */
	xAddBtn : function(pParent, pClassName, pCapt, pTitle, pNxtSib) {
		var vBtn = pParent.ownerDocument.createElement("a");
		vBtn.className = pClassName;
		vBtn.fName = pClassName;
		vBtn.href = "#";
		vBtn.target = "_self";
		if (pTitle) vBtn.setAttribute("title", pTitle);
		vBtn.innerHTML = "<span>" + pCapt + "</span>"
		if (pNxtSib) pParent.insertBefore(vBtn,pNxtSib)
		else pParent.appendChild(vBtn);
		return vBtn;
	},
	/** langMgr.xInArray : */
	xInArray : function(pArray, pVal) {
	    for(var i = 0; i < pArray.length; i++)
	    	if(pArray[i] == pVal)
	    		return true;
	    return false;
	},
	loadSortKey : "Z"
}