var lexiconMgr = {
	fPathRoot : "",
	fUrl : null,
	fStrings : ["Voir aussi","Pas de résultat"],


/* === Public functions ===================================================== */
	init : function (pPathRoot){
		scCoLib.util.log("lexiconMgr.init");
		this.fIsLocal = window.location.protocol == "file:";
		if (typeof pPathRoot != "undefined") this.fPathRoot = pPathRoot;

		scOnLoads[scOnLoads.length] = this;
	},

	declareLexicon : function(pUrl){
		scCoLib.util.log("lexiconMgr.declareLexicon: "+pUrl);
		this.fUrl = pUrl;
	},

	onLoad : function(){
		scCoLib.util.log("lexiconMgr.onLoad");
		try{
			tplMgr.registerListener("showSearchTerms", this.sOnFilter);
			tplMgr.registerListener("showSearchFull", this.sAddMoreTerms);
			tplMgr.registerListener("resetSearch", this.sOnReset);
			tplMgr.registerListener("noSearchResult", this.sNoResult);

			this.fRoot = scPaLib.findNode(this.fPathRoot);
			this.fRoot.setAttribute("aria-live", "polite");

			this.fLexiconJson = this.xGetLexicon().lexicon;
			this.fLexicon = new this.LxcManager(this.fRoot, this.fLexiconJson);
			this.fLexicon.rebuildLexicon();
		} catch(e){
			scCoLib.util.log("ERROR - lexiconMgr.onLoad: "+e);
		}
	},

	/** lexiconMgr.getPageCount : return the visible page cout the current displayed menu. */
	getPageCount : function(){
		return this.fLexicon.getPageCount();
	},

	loadSortKey : "ZZ",

/* === Callback functions =================================================== */
	/** lexiconMgr.sOnFilter : Filter callback : called on search a successful. */
	sOnFilter : function(pPageList){
		//scCoLib.util.log("lexiconMgr.sOnFilter");
		lexiconMgr.fLexicon.applyFilter(pPageList);
	},

	/** lexiconMgr.sAddMoreTerms : called on search a successful. */
	sAddMoreTerms : function(pPageList){
		//scCoLib.util.log("lexiconMgr.sOnFilter");
		lexiconMgr.fLexicon.addMoreTerms(pPageList);
	},

	/** lexiconMgr.sAddMoreTerms : called on search a successful. */
	sNoResult : function(){
		//scCoLib.util.log("lexiconMgr.sNoResult");
		lexiconMgr.fLexicon.noResult();
	},

	/** lexiconMgr.sOnReset : Filter reset callback : called search reset. */
	sOnReset : function(){
		//scCoLib.util.log("lexiconMgr.sOnReset");
		lexiconMgr.fLexicon.resetFilter();
	},

/* === Private functions ==================================================== */
	xGetLexicon : function() {
		scCoLib.util.log("lexiconMgr.xGetLexicon");
		try{
			var vReq = this.xGetHttpRequest();
			vReq.open("GET",this.fUrl,false);
			vReq.send();
			return this.xDeserialiseObjJs(vReq.responseText);
		}catch(e){
			scCoLib.util.log("ERROR - lexiconMgr.xGetLexicon : "+e);
		}
	},
	
/* === Utilities ============================================================ */
	/** lexiconMgr.xSwitchClass - replace a class name. */
	xSwitchClass : tplMgr.xSwitchClass,

	xGetHttpRequest: function(){
		if (window.XMLHttpRequest && (!this.fIsLocal || !window.ActiveXObject)) return new XMLHttpRequest();
		else if (window.ActiveXObject) return new ActiveXObject("Microsoft.XMLHTTP");
	},

	xDeserialiseObjJs : function(pStr){
		if(!pStr) return {};
		var vVal;
		eval("vVal="+pStr);
		return vVal;
	}
}

/** lexiconMgr.LxcManager - Menu manager class. */
lexiconMgr.LxcManager = function (pRoot, pLexicon, pOpt) {
	try{
		this.fOpt = {target:"_self",neverFilter:false,buildItemCallback:function(pItem){}};
		if (typeof pOpt != "undefined"){
			if (typeof pOpt.target != "undefined") this.fOpt.target = pOpt.target;
			if (typeof pOpt.neverFilter != "undefined") this.fOpt.neverFilter = pOpt.neverFilter;
			if (typeof pOpt.buildItemCallback != "undefined") this.fOpt.buildItemCallback = pOpt.buildItemCallback;
		}

		this.fRoot = pRoot;
		this.fLexicon = pLexicon;
		this.fRoot.fSrc = pLexicon;
		this.fFilter = false;
		var vFirstItem = null;
		var vItemIndex = this.fItemIndex = {};
		var vLexiconChi = [];
		var iLexiconInit = function(pItem){
			if (pItem.url){
				if (!vItemIndex[pItem.url]) vItemIndex[pItem.url] = [];
				if (!vFirstItem) vFirstItem = pItem;
				vItemIndex[pItem.url].push(pItem);
			}
			if (pItem.children) {
				for (var i=0; i<pItem.children.length; i++) {
					var vChi = pItem.children[i];
					vChi.firstlet = scServices.scSearch.normalizeString(searchMgr.fTrmUrl,vChi.title).toLowerCase().substring(0,1);
					// Réordonne le lexicon par sa première lettre
					if(!pItem.children[i-1] || vChi.firstlet!=pItem.children[i-1].firstlet) vLexiconChi.push({"title":vChi.firstlet,"children":[vChi]});
					else for (var j = 0; j < vLexiconChi.length; j++) if(vLexiconChi[j].title == vChi.firstlet) vLexiconChi[j].children.push(vChi);
					// Place le parent dans l'attribut par
					for (var j = 0; j < vLexiconChi.length; j++) vChi.par = vLexiconChi[j];
					vChi.idx = i;
					iLexiconInit(vChi);
				}
			}
		}
		iLexiconInit(this.fLexicon);
		this.fLexicon.children = vLexiconChi;

		this.fFirstItem = vFirstItem;
		this.fFirstFilteredItem = null;		

	} catch(e){scCoLib.util.log("lexiconMgr.LxcManager init : "+e);}
}
lexiconMgr.LxcManager.prototype = {
	/** LxcManager.buildSubLexicon - build the sub menu of a given root dom node. */
	buildSubLexicon : function (pRoot, pHidden) {
		//scCoLib.util.log("LxcManager.buildSubLexicon");
		var i,vChi,vUl,vTyp;
		for (i=0; i< pRoot.fSrc.children.length; i++){
			vChi = pRoot.fSrc.children[i];
			if (!this.fFilter && !vChi.prn || this.fFilter && vChi.vis){
				vTyp = vChi.children ? "b" : "l";
				this.buildLexiconEntry(pRoot, vChi, pHidden);
				if (vTyp == "b"){
					vUl = scDynUiMgr.addElement("ul",vChi.fLi,"lxc_sub lxc_sub_c");
					vUl.fSrc = vChi;
					vUl.fMgr = this;
					vChi.fUl = vUl;
					this.buildSubLexicon(vUl);
				}
			}
		}
		pRoot.fBuilt = true;
	},
	/** LxcManager.buildMenuEntry - build the menu entry of a given source node. */
	buildLexiconEntry : function(pParent, pSrc, pHidden) {
		var vUl,vLi,vDiv,vLnk,vTyp,vCls;
		var vDepht = scPaLib.findNodes("anc:.lxc_sub", pParent).length + 1;
		vTyp = pSrc.children ? "b" : "l";
		vCls = "lxc_"+vTyp+" lxc_dpt_"+vDepht+" lxc_sch_"+(this.fFilter && pSrc.act ? "yes" : "no");
		if(vDepht==1) vArticle = scDynUiMgr.addElement("article",pParent,vCls,null);
		vLi = scDynUiMgr.addElement(vDepht>1?"li":"h2",vDepht>1?pParent:vArticle,vCls,null, (pHidden ? {display:"none"} : null));
		if (vDepht==1) vLi.id=pSrc.title;
		vDiv = scDynUiMgr.addElement(vDepht>1?"div":"span",vLi, "lxcLbl accent1-text "+pSrc.type+" "+vCls+" "+pSrc.type+"-ico");
		if (pSrc.url) {
			vLnk = scDynUiMgr.addElement("a",vDiv,"lxc_i lxc_lnk");
			vLnk.href = scServices.scLoad.getPathFromRoot(pSrc.url);
			vLnk.target = this.fOpt.target;
		} else vLnk = scDynUiMgr.addElement("span",vDiv,"lxc_i lxc_lnk");
		vLnk.fSrc = pSrc;
		vLnk.fMgr = this;
		if (this.fFilter && !pSrc.act) vLnk.onclick = function(){return false};
		else vLnk.onclick = function(){try{
			this.fMgr.fRequestedItem = this.fSrc;
		}catch(e){}};
		vLnk.innerHTML = "<span class='lxc_sch'>"+pSrc.title+"</span>";
		if(this.fFilter && !pSrc.url && pSrc.title != lexiconMgr.fStrings[0]) lexiconMgr.fResBk.push(vLnk);
		pSrc.fLbl = vDiv;
		pSrc.fLi = vDepht>1?vLi:vArticle;
		pSrc.fLnk = vLnk;
		this.fOpt.buildItemCallback(pSrc);
	},
	/** LxcManager.buildAncestorLexicon - garantee that all ancestors of the given item are present. */
	buildAncestorLexicon : function(pItem, pHidden) {
		//scCoLib.util.log("LxcManager.buildAncestorLexicon");
		var vAncs = [];
		var vItem = pItem
		while(vItem.par && !vItem.fLbl){
			vAncs.push(vItem.par);
			vItem = vItem.par;
		}
		for (var i=vAncs.length-1; i>=0; i--)this.buildSubLexicon(vAncs[i].fUl, pHidden);
	},
	/** LxcManager.resetLexicon - reset all filtering info in the menu: . */
	resetLexicon : function() {
		//scCoLib.util.log("LxcManager.resetLexicon");
		var iResetLexicon = function(pItem){
			pItem.act = false;
			pItem.vis = false;
			pItem.cnt = null;
			if (pItem.children) for (var i=0; i<pItem.children.length; i++) iResetLexicon(pItem.children[i]);
		}
		iResetLexicon(this.fLexicon);
		this.fLexicon.cntAct = 0;
	},
	/** LxcManager.rebuildLexicon - Rebuild the menu from scrach. */
	rebuildLexicon : function() {
		//scCoLib.util.log("LxcManager.rebuildLexicon");
		var vMgr = this;
		var iResetLexicon = function(pItem){
			pItem.fLbl = null;
			pItem.fUl = null;
			pItem.fLi = null;
			if (!vMgr.fFilter){
				pItem.act = false;
				pItem.vis = false;
				pItem.cnt = null;
			}
			if (pItem.children) for (var i=0; i<pItem.children.length; i++) iResetLexicon(pItem.children[i]);
		}
		iResetLexicon(this.fLexicon);
		if (!this.fFilter) this.fLexicon.cntAct=0;
		this.fRoot.innerHTML = "";
		var vRootUl = scDynUiMgr.addElement("div",this.fRoot,"lxc_root lxc_sub lxc_sch_no");
		vRootUl.fSrc = this.fLexicon;
		var count = 0;

    	for(var prop in this.fItemIndex) {
        if(this.fItemIndex.hasOwnProperty(prop))
            ++count;
    }
		if((this.fLexicon.children.length>1)&&(count>14)) {
			var vAlphabar = this.fAlphabar =scDynUiMgr.addElement("h2",vRootUl,"alphabar");
		for (var i=0;i<this.fLexicon.children.length;i++) {
			var vAlpha = scDynUiMgr.addElement("a",vAlphabar,"");
			vAlpha.setAttribute("href","#"+this.fLexicon.children[i].title);
			vAlpha.innerHTML = this.fLexicon.children[i].title;
			var vSep = scDynUiMgr.addElement("span",vAlphabar,"alphasep");
			vSep.innerHTML = " - ";
		}
		}
		this.buildSubLexicon(vRootUl);
	},


	/** LxcManager.getPageCount - return filtered page cout. */
	getPageCount : function(){
		return this.fLexicon.cntAct;
	},
	/** LxcManager.addMoreTerms - add terms in full text in a new entry See also. */
	addMoreTerms : function(pPageList) {
		if(!pPageList || pPageList.length == 0) return;		
		var vRootUl = scDynUiMgr.addElement("ul",this.fRoot,"lxc_root lxc_sub lxc_sch_no");
		vRootUl.fSrc = {children:[{title:lexiconMgr.fStrings[0],children:[],vis:true}]};
		for (var i=0; i<pPageList.length; i++){
			var vItems = this.fItemIndex[pPageList[i].url];
			if (vItems)
				for (var j=0; j<vItems.length; j++){
					var vItem=vItems[j];
					vItem.vis=true;
					vItem.act=true;
					vItem.cat=pPageList[i].cat;
					vRootUl.fSrc.children[0].children.push(vItem)
				}
		}
		this.buildSubLexicon(vRootUl);
	},
	/** LxcManager.applyFilter - apply a filter on the menu based on the given array of vidible pages. */
	applyFilter : function(pPageList) {
		if (this.fOpt.neverFilter) return;
		//scCoLib.util.log("LxcManager.applyFilter");
		this.resetLexicon();
		this.fFilter = true;
		lexiconMgr.fResBk = [];
		for (var i=0; i<pPageList.length; i++){
			var vItems = this.fItemIndex[pPageList[i]];
			if (vItems){
				for (var j=0; j<vItems.length; j++){
					var vItem = vItems[j];
					vItem.vis = true;
					vItem.act = true;
					this.fLexicon.cntAct++;
					while (vItem.par && !vItem.par.vis){
						vItem = vItem.par;
						vItem.vis = true;
					}
				}
			}
		}
		this.rebuildLexicon();
		if (this.fAlphabar) this.fAlphabar.innerHTML="";
		if (pPageList.length>14) {

			var activeLetter="";
			for (var i=0;i<pPageList.length;i++) {
				if (this.fItemIndex[pPageList[i]][0].firstlet != activeLetter) {
					activeLetter=this.fItemIndex[pPageList[i]][0].firstlet;
					var vAlpha = scDynUiMgr.addElement("a",this.fAlphabar,"");
					vAlpha.setAttribute("href","#"+activeLetter);
					vAlpha.innerHTML = activeLetter;
					var vSep = scDynUiMgr.addElement("span",this.fAlphabar,"alphasep");
					vSep.innerHTML = " - ";
				}
			}

		}
		lexiconMgr.xSwitchClass(this.fRoot, "lxc_sch_no", "lxc_sch_yes");
	},
	/** LxcManager.resetFilter - resert the current filter and rebuild the menu. */
	noResult : function() {
		//scCoLib.util.log("LxcManager.resetFilter");
		var vMoreTerms = this.fRoot.childNodes.length>1?this.fRoot.childNodes[this.fRoot.childNodes.length-1]:"";
		this.fRoot.innerHTML = "";
		var vRootNoRes = scDynUiMgr.addElement("div",this.fRoot,"lxc_sch_nores");
		vRootNoRes.innerHTML = "<span>"+lexiconMgr.fStrings[1]+"</span>";
		if(vMoreTerms) this.fRoot.innerHTML += vMoreTerms.outerHTML;
	},
	/** LxcManager.resetFilter - reset the current filter and rebuild the menu. */
	resetFilter : function() {
		//scCoLib.util.log("LxcManager.resetFilter");
		this.fFilter = false;
		this.rebuildLexicon();
		this.fFirstFilteredItem = null;
		lexiconMgr.xSwitchClass(this.fRoot, "lxc_sch_yes", "lxc_sch_no");
		if (this.fCurrItem) this.loadPage(this.fCurrItem.url);
	},
	loadSortKey: "ZLexiconMgr"
}
