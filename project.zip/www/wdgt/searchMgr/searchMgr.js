/**
 * LICENCE[[
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1/CeCILL 2.O
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is kelis.fr code.
 *
 * The Initial Developer of the Original Code is 
 * samuel.monsarrat@kelis.fr
 *
 * Portions created by the Initial Developer are Copyright (C) 2012-2013
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * nicolas.boyer@kelis.fr
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either of the GNU General Public License Version 2 or later (the "GPL"),
 * or the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * or the CeCILL Licence Version 2.0 (http://www.cecill.info/licences.en.html),
 * in which case the provisions of the GPL, the LGPL or the CeCILL are applicable
 * instead of those above. If you wish to allow use of your version of this file
 * only under the terms of either the GPL, the LGPL or the CeCILL, and not to allow
 * others to use your version of this file under the terms of the MPL, indicate
 * your decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL, the LGPL or the CeCILL. If you do not
 * delete the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL, the LGPL or the CeCILL.
 * ]]LICENCE
 */

/* ========== Search manager ================================================ */
var searchMgr = {
	fPathRoot : "des:div",
	fPathIntroPanel : "ide:tplMain/des:.bkIntro/des:.panel-collapse",
	fPathIntroTitle : "ide:tplMain/des:.bkIntro/des:.accordion-toggle",
	fPathSchBox : "",
	fPathResBox : "",
	fOverflowMethod : "",
	fType: "",
	fFilter : false,
	fDynamic : true,
	fResultFilters : {ctrl:{},list:[]},
	fStrings : ["Annuler","Annuler la recherche",
	/*02*/      "Rechercher dans le contenu","Aucun résultat.",
	/*04*/      "1 page trouvée","%s pages trouvées",
	/*06*/      "Précisez votre recherche...","Termes recherchés :",
	/*08*/      "Précédent","Occurrence précédente",
	/*10*/      "Suivant","Occurrence suivante",
	/*12*/      "Page précédente","Page suivante",
	/*14*/      "Liste","Afficher/cacher la liste des pages trouvées",
	/*16*/      "%s occurrences","1 occurrence",
	/*18*/      "plus de 8 occurrences","%s",
	/*20*/      "Pas de résultat de recherche","Rechercher",
	/*22*/      "Ouvrir le menu","Fermer le menu",
	/*24*/      "Valider ma recherche","Valider",
	/*26*/      "Rechercher",""],

/* ========== Public functions ============================================== */

	declareTerm: function(pIdx){
		//scCoLib.util.log("searchMgr.declareTerm : "+pIdx);
		this.fTrmUrl = pIdx;
	},

	declareIndex: function(pIdx){
		//scCoLib.util.log("searchMgr.declareIndex : "+pIdx);
		this.fIdxUrl = pIdx;
	},

	declareFilters: function(pIdx){
		//scCoLib.util.log("searchMgr.declareFilters : "+pIdx);
		this.fFtrUrl = pIdx;
	},

	setDynamic: function(pFlag){
		scCoLib.util.log("searchMgr.setDynamic : "+pFlag);
		this.fDynamic = pFlag;
	},

	init: function(pPathSchBox){
		scCoLib.util.log("searchMgr.init");
		if (typeof pPathSchBox != "undefined") this.fPathSchBox = pPathSchBox;

		this.fRoot = scPaLib.findNode(this.fPathRoot);
		this.fIntro = scPaLib.findNode(this.fPathIntroPanel, this.fRoot);
		this.fIntroTitle = scPaLib.findNode(this.fPathIntroTitle, this.fRoot);
		if (this.fIntro){
			this.fIntro.fTitle = scPaLib.findNode("chi:h\\d/chi:a", this.fIntro);
			this.fIntro.fCo = scPaLib.findNode("chl:div", this.fIntro);
		}
		var vSchBox = this.fSchBox = scPaLib.findNode(this.fPathSchBox);
		if (!vSchBox) return;








		if(vSchBox) vSearchCmds = this.fSearchCmds = scDynUiMgr.addElement("div",vSchBox,"dark-bg text-center-xs container-fluid");

		var vForm1 = this.fForm1 = scDynUiMgr.addElement("form",vSearchCmds,"navbar-form navbar-right");
		vForm1.setAttribute("role","search");

		var vFormGroup1 = this.fFormGroup1 = scDynUiMgr.addElement("div",vForm1,"form-group");

		var vInputGroup1 = this.fInputGroup1 = scDynUiMgr.addElement("span",vFormGroup1,"input-group");
		var vInputGroupBtn1 = this.fInputGroupBtn1 = scDynUiMgr.addElement("span",vInputGroup1,"input-group-btn");
		var vButton1 = this.fButton1 = scDynUiMgr.addElement("button",vInputGroupBtn1,"btn btn-default schBtnReset");
		vButton1.innerHTML = '<span class="glyphicon glyphicon-refresh"></span>';
		vButton1.title = this.fStrings[1];
		vButton1.setAttribute("tabindex","12");
		vButton1.onclick = this.resetall;

		var vSearchInput= this.fSearchInput = scDynUiMgr.addElement("input",vInputGroup1,"form-control schInput");
		vSearchInput.type = "text";
		vSearchInput.setAttribute("tabindex","13");
		vSearchInput.id = vSearchInput.name = this.fStrings[21];
		vSearchInput.placeholder = this.fStrings[26];
		vSearchInput.title = this.fStrings[2];
		vSearchInput.onkeyup = this.sKeyUp;


		var vInputAddon1 = this.fInputAddon = scDynUiMgr.addElement("span",vInputGroup1,"input-group-addon");
		vInputAddon1.setAttribute("aria-hidden","true");
		vInputAddon1.innerHTML = '<span class="glyphicon glyphicon-search"></span>';






//var scDynUiMgr.addElement("",,"");

		
		if (!this.fDynamic){
			this.fSearchPropose = scDynUiMgr.addElement("div",this.fSearchForm,"schPropose schProp_no");
			this.fSearchPropose.setAttribute("aria-live", "polite");
		}
		
		


			
		scOnLoads[scOnLoads.length] = this;
	},

	onLoad: function(){
		//scCoLib.util.log("searchMgr.onLoad");
		try{
			if(this.fFilter) {
				this.findFilters();
				if(!tplMgr.fStore.get("input")) this.find();
			}
			if(tplMgr.fStore.get("input")) {
				this.fSearchInput.value = tplMgr.fStore.get("input");
				this.find();
			}
		}catch(e){scCoLib.util.log("ERROR - searchMgr.onLoad : "+e)}
	},

	focus: function(){
	 	if (this.fSearchInput) this.fSearchInput.focus();
	},

	propose: function(){
		//scCoLib.util.log("searchMgr.propose");
		try{
			var vStr = this.fSearchInput.value;
			var vWds = scServices.scSearch.propose(this.fTrmUrl, vStr,{filter:this.fResultFilters});
			var vShowProp = !vWds || (vWds && vWds.length==0 && vStr.length<3) || vWds && vWds.length>0;
			this.xSwitchClass(this.fSearchPropose,"schProp_"+(vShowProp ? "no" : "yes"), "schProp_"+(vShowProp ? "yes" : "no"), true);
			this.fSearchPropose.fShown = vShowProp ? true : false;
		
			var vProp;
			this.fSearchPropose.innerHTML = "";
			if (vWds && vWds.length>0){
				for(var i = 0;i<vWds.length;i++){
					vProp = this.xAddBtn(this.fSearchPropose,"schBtnPropose",vWds[i].wrd);
					vProp.onclick = this.sProp;
					vProp.onkeydown = this.sPropKey;
				}
			} else if (!vWds || vWds && vWds.length==0){
				scDynUiMgr.addElement("span", this.fSearchPropose,"schProposeExceeded").innerHTML=this.fStrings[6];
			}
		}catch(e){scCoLib.util.log("ERROR - searchMgr.propose : "+e)}
	},


	findFilters: function(){
		// scCoLib.util.log("searchMgr.findFilter");
		var vResponses = [], vCrits = scPaLib.findNodes("des:input.schCrit");
		this.fFilter = false;
		for (var i=0; i<vCrits.length; i++){
			var vCrit = vCrits[i];
			if (vCrit.getAttribute("data-ison")=="true") {
				vResponses[vResponses.length] = scServices.scSearch.find(vCrit.getAttribute("data-index"), vCrit.getAttribute("data-val"), {catMask:vCrit.getAttribute("data-cat"),returnResultSet:true});
				tplMgr.fStore.set(vCrit.getAttribute("data-val"),true);
				this.fFilter = true;
			} else tplMgr.fStore.set(vCrit.getAttribute("data-val"),"");
		}
		this.fResultFilters = scServices.scSearch.consolidateResults(vResponses,{returnResultSet:true});
	},

	find: function(){
		scCoLib.util.log("searchMgr.find");
		if(this.fSearchInput) tplMgr.fStore.set("input",this.fSearchInput.value);
		var vStr = this.fSearchInput.value;
		
		//if(!vStr && !this.fFilter) return;

		//if (this.fIntro && !this.fIntro.fCo.fCollapsed){
		//	this.fIntro.fTitle.onclick();
		//}
		
		if ((vStr || this.fFilter) && (this.fIntro)) this.fIntro.setAttribute("class","panel-collapse collapse");
		if ((vStr || this.fFilter) && (this.fIntro)) this.fIntroTitle.setAttribute("class","accordion-toggle collapsed");
		
		if (!this.fDynamic){
			this.xSwitchClass(this.fSearchPropose,"schProp_yes", "schProp_no", true);
			this.fSearchPropose.fShown = false;
			this.fSearchPropose.innerHTML = "";
		}
		
		var vResultTermList = [], vResultFullList = [], vResultFullFilter = [], vResultTermFilter = [];

		if(vStr || this.fFilter) {
			// Recherche des termes et filtres
			var vResultTerm = scServices.scSearch.query({id:this.fTrmUrl,str:vStr,opt:{singleToken:true,matchStartOnly:true}});
			if(this.fFilter) vResultTermFilter.push(this.fResultFilters);
			if(vStr) vResultTermFilter.push(vResultTerm);
			this.fResult = scServices.scSearch.consolidateResults(vResultTermFilter);
			for (var i =0; i<this.fResult.length; i++) vResultTermList.push(this.fResult[i].url);
			tplMgr.fireEvent("showSearchTerms", vResultTermList);
			
			// Recherche full text, filtres et dédoublonnage
			if (vStr.length >=3){
				var vResultFull = scServices.scSearch.query({id:this.fIdxUrl,str:vStr,opt:{}});
				if(this.fFilter) vResultFullFilter.push(this.fResultFilters);
				if(vStr) vResultFullFilter.push(vResultFull);
				vResultFullFilter = scServices.scSearch.consolidateResults(vResultFullFilter,{returnResultSet:true});
				for (var i =0; i<vResultFullFilter.list.length; i++) {
					if (typeof vResultTerm.ctrl[vResultFullFilter.list[i].url] == "undefined") vResultFullList.push(vResultFullFilter.list[i]);
				}
				tplMgr.fireEvent("showSearchFull", searchMgr.xSortArrayByKey(vResultFullList,'cat',true));
			}

			if(vStr) this.xUpdateUi();
			if(!this.fResult.length) tplMgr.fireEvent("noSearchResult");
		} else 	tplMgr.fireEvent("resetSearch");
	},

	reset: function(){
		if (!this.fSearchDisplay) return;
		scServices.scSearch.resetLastQuery();
		searchMgr.xResetUi();
		if(this.fFilter == true) {
			searchMgr.findFilters();
			searchMgr.find();
		} else tplMgr.fireEvent("resetSearch");
	},
	
	resetall: function(){
		scServices.scSearch.resetLastQuery();
		searchMgr.xResetUi();
		for (var i = 0; i < categoryMgr.fCatBtns.length; i++) {
			var vSchFilter = categoryMgr.fCatBtns[i];
			vSchFilter.checked=false;
			vSchFilter.setAttribute("data-ison",false);
		}
		searchMgr.fFilter = false;
		if(this.fFilter == true) {
			searchMgr.findFilters();
			searchMgr.find();
		} else tplMgr.fireEvent("resetSearch");
	},

/* === Callback functions =================================================== */
	sReset: function(){
		searchMgr.reset();
		return false;
	},

	sFind: function(){
		searchMgr.find();
		return false;
	},

	sProp: function(){
		searchMgr.fSearchInput.value = this.firstChild.innerHTML;
		searchMgr.find();
		return false;
	},

	sPropKey: function(pEvt){
		var vEvt = pEvt || window.event;
		var vNode;
		switch(vEvt.keyCode){
		case 40:
			vNode = scPaLib.findNode("nsi:a",this);
			break;
		case 38:
			vNode = scPaLib.findNode("psi:a",this);
			if(!vNode) vNode = scPaLib.findNode("anc:.schCmds/chi:.schInput",this);
		}
		if (vNode) {
			vNode.focus();
			if (vEvt.preventDefault) vEvt.preventDefault();
		}
	},

	sKeyUp: function(pEvt){
		var vEvt = pEvt || window.event;

		if (this.value.length>0) searchMgr.xSwitchClass(searchMgr.fSearchCmds,"schCmds_noact", "schCmds_act", true);
		else searchMgr.xSwitchClass(searchMgr.fSearchCmds,"schCmds_act", "schCmds_noact", true);
		
		if (this.value.length==0) searchMgr.sReset();
		if (!searchMgr.fDynamic){
			if (this.value.length>0 && vEvt.keyCode != "13") searchMgr.propose();
			else {
				searchMgr.xSwitchClass(searchMgr.fSearchPropose,"schProp_yes", "schProp_no", true);
				searchMgr.fSearchPropose.fShown = false;
				searchMgr.fSearchPropose.innerHTML = "";
			}
			if (searchMgr.fSearchPropose.fShown && vEvt.keyCode == "40") {
				var vProp = scPaLib.findNode("chi.a",searchMgr.fSearchPropose);
				if (vProp) vProp.focus();
			}
		} else {
			searchMgr.find();
		}

		if (vEvt.stopPropagation) vEvt.stopPropagation();
		else vEvt.cancelBubble = true;
	},

	/* ========== Private functions =========================================== */
	xResetUi: function(){
		if (!this.fSearchDisplay) return;
		scCoLib.util.log("searchMgr.xResetUi");
		this.fSearchDisplay = false;
		this.xSwitchClass(this.fRoot, "schDisplay_on", "schDisplay_off", true);
		this.xSwitchClass(this.fRoot, "schDisplayList_on", "schDisplayist_off", true);
		this.fSearchInput.value = "";
		this.fSearchInput.className = "schInput form-control";
		if (!this.fDynamic){
			this.xSwitchClass(searchMgr.fSearchPropose,"schProp_yes", "schProp_no", true);
			this.fSearchPropose.innerHTML = "";
		}
		tplMgr.fStore.set("input","");
	},

	xUpdateUi: function(){
		if (this.fSearchInput.value.length>0) searchMgr.xSwitchClass(this.fSearchCmds,"schCmds_noact", "schCmds_act", true);
		else searchMgr.xSwitchClass(this.fSearchCmds,"schCmds_act", "schCmds_noact", true);

		if (!this.fResult) return;

		this.fSearchDisplay = true;
		searchMgr.xSwitchClass(searchMgr.fRoot, "schDisplay_off", "schDisplay_on", true);

		if (this.fResult && this.fResult.length > 0) searchMgr.xUpdateResUi();
	},

	xUpdateResUi: function(){
		scCoLib.util.log("searchMgr.xUpdateResUi");
		var vPageCount = lexiconMgr.getPageCount();
		if (vPageCount && vPageCount > 0) {
			var vStrPgeCount = vPageCount == 1 ? this.fStrings[4] : this.fStrings[5].replace("%s",vPageCount);
			if (lexiconMgr.fResBk.length > 1) {
				var vAncSection = scPaLib.findNode("anc:section",lexiconMgr.fResBk[0]),
					vAncTi = scDynUiMgr.addElement("h2",vAncSection,"lxc_gpe_ti",vAncSection.firstChild);
				vAncTi.innerHTML = "<span>"+vStrPgeCount+"</span>";
			}
			else lexiconMgr.fResBk[0].innerHTML = vStrPgeCount;
		}
	},
	
	/* === Utilities ============================================================ */
	/** searchMgr.xAddBtn : Add a HTML button to a parent node. */
	xAddBtn : tplMgr.xAddBtn,

	/** searchMgr.xSwitchClass - replace a class name. */
	xSwitchClass : tplMgr.xSwitchClass,

	xSortArrayByKey : function(pArray, pKey, pDesc) {
	    pArray = (pArray instanceof Array ? pArray : []);
	    var vNewArray = pArray.sort(function (a, b) {
	        return (typeof(a[pKey]) === 'number' ?  pDesc ? a[pKey] - b[pKey] : a[pKey] - b[pKey] : pDesc ? a[pKey] < b[pKey] : a[pKey] > b[pKey]);
	    });
	    return vNewArray;
	},

	loadSortKey: "ZZsearchMgr"
}